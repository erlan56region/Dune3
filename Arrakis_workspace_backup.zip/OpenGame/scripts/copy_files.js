#!/usr/bin/env node

/**
 * @license
 * Copyright 2025 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */

// Copyright 2025 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import fs from 'node:fs';
import path from 'node:path';

const sourceDir = path.join('src');
const targetDir = path.join('dist', 'src');

const extensionsToCopy = ['.md', '.json', '.sb', '.sf2'];

function copyFilesRecursive(source, target, rootSourceDir) {
  if (!fs.existsSync(target)) {
    fs.mkdirSync(target, { recursive: true });
  }

  const items = fs.readdirSync(source, { withFileTypes: true });

  for (const item of items) {
    const sourcePath = path.join(source, item.name);
    const targetPath = path.join(target, item.name);

    if (item.isDirectory()) {
      copyFilesRecursive(sourcePath, targetPath, rootSourceDir);
    } else {
      const ext = path.extname(item.name);
      // Copy standard extensions, or .js files in i18n/locales directory
      // Use path.relative for precise matching to avoid false positives
      const relativePath = path.relative(rootSourceDir, sourcePath);
      const normalizedPath = relativePath.replace(/\\/g, '/');
      const isLocaleJs =
        ext === '.js' && normalizedPath.startsWith('i18n/locales/');
      if (extensionsToCopy.includes(ext) || isLocaleJs) {
        fs.copyFileSync(sourcePath, targetPath);
      }
    }
  }
}

if (!fs.existsSync(sourceDir)) {
  console.error(`Source directory ${sourceDir} not found.`);
  process.exit(1);
}

copyFilesRecursive(sourceDir, targetDir, sourceDir);

// Copy example extensions into the bundle.
const packageName = path.basename(process.cwd());
if (packageName === 'cli') {
  const examplesSource = path.join(
    sourceDir,
    'commands',
    'extensions',
    'examples',
  );
  const examplesTarget = path.join(
    targetDir,
    'commands',
    'extensions',
    'examples',
  );
  if (fs.existsSync(examplesSource)) {
    fs.cpSync(examplesSource, examplesTarget, { recursive: true });
  }
}

console.log('Successfully copied files.');
