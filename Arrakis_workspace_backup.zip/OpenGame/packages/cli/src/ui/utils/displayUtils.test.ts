/**
 * @license
 * Copyright 2025 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */

import { describe, it, expect } from 'vitest';
import {
  getStatusColor,
  TOOL_SUCCESS_RATE_HIGH,
  TOOL_SUCCESS_RATE_MEDIUM,
  USER_AGREEMENT_RATE_HIGH,
  USER_AGREEMENT_RATE_MEDIUM,
  CACHE_EFFICIENCY_HIGH,
  CACHE_EFFICIENCY_MEDIUM,
} from './displayUtils.js';
import { theme } from '../semantic-colors.js';

describe('displayUtils', () => {
  describe('getStatusColor', () => {
    describe('with red threshold', () => {
      const thresholds = {
        green: 80,
        yellow: 50,
        red: 20,
      };

      it('should return green for values >= green threshold', () => {
        expect(getStatusColor(90, thresholds)).toBe(theme.status.success);
        expect(getStatusColor(80, thresholds)).toBe(theme.status.success);
      });

      it('should return yellow for values < green and >= yellow threshold', () => {
        expect(getStatusColor(79, thresholds)).toBe(theme.status.warning);
        expect(getStatusColor(50, thresholds)).toBe(theme.status.warning);
      });

      it('should return red for values < yellow and >= red threshold', () => {
        expect(getStatusColor(49, thresholds)).toBe(theme.status.error);
        expect(getStatusColor(20, thresholds)).toBe(theme.status.error);
      });

      it('should return error for values < red threshold', () => {
        expect(getStatusColor(19, thresholds)).toBe(theme.status.error);
        expect(getStatusColor(0, thresholds)).toBe(theme.status.error);
      });

      it('should return defaultColor for values < red threshold when provided', () => {
        expect(
          getStatusColor(19, thresholds, { defaultColor: theme.text.primary }),
        ).toBe(theme.text.primary);
      });
    });

    describe('when red threshold is not provided', () => {
      const thresholds = {
        green: 80,
        yellow: 50,
      };

      it('should return error color for values < yellow threshold', () => {
        expect(getStatusColor(49, thresholds)).toBe(theme.status.error);
      });

      it('should return defaultColor for values < yellow threshold when provided', () => {
        expect(
          getStatusColor(49, thresholds, { defaultColor: theme.text.primary }),
        ).toBe(theme.text.primary);
      });
    });
  });

  describe('Threshold Constants', () => {
    it('should have the correct values', () => {
      expect(TOOL_SUCCESS_RATE_HIGH).toBe(95);
      expect(TOOL_SUCCESS_RATE_MEDIUM).toBe(85);
      expect(USER_AGREEMENT_RATE_HIGH).toBe(75);
      expect(USER_AGREEMENT_RATE_MEDIUM).toBe(45);
      expect(CACHE_EFFICIENCY_HIGH).toBe(40);
      expect(CACHE_EFFICIENCY_MEDIUM).toBe(15);
    });
  });
});
